<?php
if(isset($testeur) && $testeur == "lobo951")
	{
	$db_adr = 'localhost';
	$db_login = 'root';
	$db_password = 'password';
	$db_name = 'hhwt';
	}
?>