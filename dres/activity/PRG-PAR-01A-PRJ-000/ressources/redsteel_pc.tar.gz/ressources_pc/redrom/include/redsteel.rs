
#ifndef		__REDSTEEL_RS__
# define	__REDSTEEL_RS__

# define	ROM			0x0000
# define	CARTRIDGE		0x2001
# define	RAM			0x4002
# define	KEYBOARD		0x6000
# define	VIDEO			0x8001
# define	SOUND			0xA002
# define	DRIVE			0xC000
# define	NETWORK			0xE001

#endif
