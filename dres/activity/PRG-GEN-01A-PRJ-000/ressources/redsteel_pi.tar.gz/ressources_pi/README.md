Emulateur de RedSteel
=====================

L'ensemble des logiciels requis pour le projet RedSteel, travail de premier cycle du cursus de "La Caverne Aux Lapins Noirs".
Ce projet a pour objet la programmation soit d'un micro-processeur virtuel, soit d'un logiciel d'assemblage associé.

L'objectif du projet est l'apprentissage de la nature profonde des ordinateurs ainsi que du langage assembleur.
