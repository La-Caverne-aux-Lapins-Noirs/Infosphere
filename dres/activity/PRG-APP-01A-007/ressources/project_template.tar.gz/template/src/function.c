/*
** Jason Brillante "Damdoshi"
** Pentacle Technologie 2008-2021
** Hanged Bunny Studio 2014-2021
**
** - Project template -
*/

#include	<unistd.h>
#include	"placeholder.h"

int		function(void)
{
  return (write(1, "Function\n", sizeof("Function\n") - 1));
}
