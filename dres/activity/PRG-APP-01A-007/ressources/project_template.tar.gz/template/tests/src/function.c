/*
** Jason Brillante "Damdoshi"
** Pentacle Technologie 2008-2021
** Hanged Bunny Studio 2014-2021
**
** - Project template -
*/

#include	<assert.h>
#include	"placeholder.h"

int		main(void)
{
  assert(function() == 9);
}

