/*
** Jason Brillante "Damdoshi"
** Pentacle Technologie 2008-2021
** Hanged Bunny Studio 2014-2021
**
** - Project template -
*/

#ifndef		__PLACEHOLDER_H__
# define	__PLACEHOLDER_H__

int		function(void);

#endif	/*	__PLACEHOLDER_H__	*/
